import zoneinfo
from apscheduler.schedulers.background import BackgroundScheduler

from .support.scheduler_functions import check_expiry

scheduler = BackgroundScheduler()

utc = zoneinfo.ZoneInfo("UTC")
scheduler.add_job(check_expiry, 'cron', hour=1, timezone=utc)
