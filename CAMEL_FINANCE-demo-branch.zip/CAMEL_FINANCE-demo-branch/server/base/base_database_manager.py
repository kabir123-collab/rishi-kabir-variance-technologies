from abc import ABC, abstractmethod
from ..support.functions import log
from ..support.enums import LogType
 
class BaseDatabaseManager(ABC):
    
    ID = "BASE_DATABASE_MANAGER"
    client = None

    def __init__(self, credentials: dict):
        self.credentials = credentials

        self.db = None
        self.tables = None
        self.logger = lambda x, y: log(x, f"DB: {y}")

        self.__handlers = {}
    

    #* Handlers
    def add_on_start_handler(self, handler) -> None:
        self.__handlers["on_start"] = handler

    def add_on_stop_handler(self, handler) -> None:
        self.__handlers["on_stop"] = handler

    def add_on_error_handler(self, handler) -> None:
        self.__handlers["on_error"] = handler

    def on_start(self, message: str = "STARTED") -> None:
        if "on_start" in self.__handlers:
            self.__handlers["on_start"]()
        self.logger(LogType.INFO, message)
    
    def on_stop(self, message: str = "STOPPED") -> None:
        if "on_stop" in self.__handlers:
            self.__handlers["on_stop"]()
        self.logger(LogType.INFO, message)

    def on_error(self, message: str = "ERROR") -> None:
        if "on_error" in self.__handlers:
            self.__handlers["on_error"]()
        self.logger(LogType.ERROR, message)

    #* Client related
    @abstractmethod
    def connect_client(self) -> bool:
        ...

    @abstractmethod
    def disconnect_client(self):
        self.client = None
        ...

    #* Database related
    @abstractmethod
    def create_database(self):
        ...

    @abstractmethod
    def use_database(self):
        ...

    @abstractmethod
    def drop_database(self):
        ...

    #* Table related
    @abstractmethod
    def create_table(self):
        ...

    @abstractmethod
    def alter_table(self):
        ...
    
    @abstractmethod
    def delete_table(self):
        ...

    @abstractmethod
    def modify_table(self):
        ...

    @abstractmethod
    def update_table(self):
        ...

    #* Record related
    @abstractmethod
    def insert_into_table(self):
        ...
    
    @abstractmethod
    def select_from_table(self):
        ...

    @abstractmethod
    def delete_from_table(self):
        ...