from datetime import datetime
import json
import traceback
import uuid
from pymongo import DESCENDING
from pymongo.database import Database
from cryptography.fernet import Fernet
import os, secrets
import dns.resolver


from .enums import *
import os
import requests
from .tradingview import TradingView

with open("credentials.json", "r") as file:
    credentials = json.load(file)
    file.close() 
STRATEGY_NAME = credentials[CREDENTIALS_KEYS.STRATEGY_NAME]
SECRET_KEY = "ydHdql3vpNvNQEAxxmd3gDnU5lAvguOrjmHMjTx5DOY="
fernet = Fernet(SECRET_KEY)

URL_MAPPINGS_FOR_TRADINGVIEW_CODE = {
    "VALIDATE": "http://127.0.0.1:5000/validate/",
    "ACCESS": "http://127.0.0.1:5000/access/",
}
DT_FORMAT = "%Y-%m-%d %H:%M:%S"

def log(log_type: LogType, message: str):
    os.makedirs(os.path.join("content", "logs"), exist_ok=True)
    current_datetime = datetime.now()
    message = f"{current_datetime} : {log_type.upper()}: {message}"
    try:
        print(message)
        with open(os.path.join("content", "logs", f"{current_datetime.date().strftime('%Y-%m-%d')}.txt"), "a+") as f:
            f.write(f"{message}\n")
            f.close()
    except:
        ...

def check_if_ran_first_time(db: Database, admin_username: str, admin_password: str, admin_token: str):
    """
    Our DB structure will be as follows:

    # ADMIN: with one super user
        - username      TEXT
        - password      TEXT
        - token         TEXT
    
    # SUBSCRIBERS: will contain all the details for the subscribers
        - subid         TEXT
        - username      TEXT
        - fullname      TEXT
        - email         TEXT
        - status        TEXT

    # TRANSACTIONS: will contain all the transaction details
        - subid                   TEXT
        - create_time             TEXT
        - last_updated_time       TEXT
        - expiration              TEXT
        - expiration_timestamp    INT
        - expired                 BOOL
    
    # TRANSACTIONS: will contain all the failed details
        - sub_name          TEXT
        - strategy_name     TEXT
        - create_time       TEXT
        - reason            TEXT
    """

    
    collections = db.list_collection_names()
    if TABLES.ADMIN not in collections:
        db.create_collection("ADMIN", validator={
            "$jsonSchema": {
                "bsonType": "object",
                "required": ["username", "password", "token"],
                "properties": {
                    "username": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    },
                    "password": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                    "token": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    }
                }
            }
        })
    
    db[TABLES.ADMIN].update_one({ADMIN_TABLE.USERNAME: admin_username, ADMIN_TABLE.PASSWORD: admin_password}, {"$set":{ADMIN_TABLE.USERNAME: admin_username, ADMIN_TABLE.PASSWORD: admin_password, ADMIN_TABLE.TOKEN: admin_token}}, upsert=True)
    
    if TABLES.SUBSCRIBERS not in collections:
        db.create_collection("SUBSCRIBERS", validator={
            "$jsonSchema": {
                "bsonType": "object",
                "required": ["subid", "created_time", "username", "fullname", "email", "email_valid", "status"],
                "properties": {
                    "subid": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    },
                    "created_time": {
                        "bsonType": "string",
                        "description": "must be a valid string and is required"
                    },
                    "username": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                    "fullname": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    },
                    "email": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                    "email_valid": {
                        "bsonType": "bool",
                        "description": "must be a boolean and is required"
                    },
                    "status": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    }
                }
            }
        })
    if TABLES.PAYMENT not in collections:
        db.create_collection("PAYMENT", validator={
            "$jsonSchema": {
                "bsonType": "object",
                "required": ["request_id", "subid", "status", "created_time", "reason"],
                "properties": {
                    "request_id": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    },
                    "subid": {
                        "bsonType": "string",
                        "description": "must be an int and is required"
                    },
                    "status": {
                        "bsonType": "string",
                        "description": "must be a valid string and is required"
                    },
                    "created_time": {
                        "bsonType": "string",
                        "description": "must be a valid string and is required"
                    },
                    "reason": {
                        "bsonType": "string",
                        "description": "must be a valid string and is required"
                    }
                }
            }
        })
    
    if TABLES.SUCCESS not in collections:
        db.create_collection("SUCCESS", validator={
            "$jsonSchema": {
                "bsonType": "object",
                "required": ["subid","create_time","last_updated_time","expiration","expiration_timestamp","expired"],
                "properties": {
                    "subid": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    },
                    "create_time": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                    "last_updated_time": {
                        "bsonType": "string",
                        "description": "must be a valid string and is required"
                    },
                    "expiration": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                    "expiration_timestamp": {
                        "bsonType": "double",
                        "description": "must be a valid double and is required"
                    },
                    "expired": {
                        "bsonType": "bool",
                        "description": "must be a valid bool and is required"
                    }
                }
            }
        })

    if TABLES.FAILED not in collections:
        db.create_collection("FAILED", validator={
            "$jsonSchema": {
                "bsonType": "object",
                "required": ["sub_name","strategy_name","create_time","reason"],
                "properties": {
                    "sub_name": {
                        "bsonType": "string",
                        "description": "must be a string and is required"
                    },
                    "strategy_name": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                    "create_time": {
                        "bsonType": "string",
                        "description": "must be a valid string and is required"
                    },
                    "reason": {
                        "bsonType": "string",
                        "description": "must be an string and is required"
                    },
                }
            }
        })


def create_subscriber(db_instance: Database, sub_id: str, email: str, fullname: str, tradingview_username):
    
	valid_email = validate_email(email)
	if valid_email:
		log(LogType.INFO, f"Provided email, {email} is Valid, BY ADMIN")
	else:
		log(LogType.INFO, f"Provided email, {email} is Invalid, BY ADMIN")

	insert = {
		SUBSCRIBERS_TABLE.SUB_ID: sub_id,
		SUBSCRIBERS_TABLE.CREATED_TIME: datetime.now().strftime(DT_FORMAT),
		SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT),
		SUBSCRIBERS_TABLE.FULLNAME: fullname,
		SUBSCRIBERS_TABLE.USERNAME: tradingview_username.lower(),
		SUBSCRIBERS_TABLE.EMAIL: email,
		SUBSCRIBERS_TABLE.EMAIL_VALID: valid_email,
		SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.ACTIVE,
	}
	db_instance[TABLES.SUBSCRIBERS].insert_one(insert)

def verify_user(username: str) -> bool:
    try:
        tv = TradingView()
        response = tv.validate_username(username)
        j = json.dumps(response)
        boolean = response["validuser"]
        return boolean
    except Exception:
        log(LogType.ERROR, traceback.format_exc(limit=1))
        return None

def get_access(username: str, payload: dict) -> list | None:
    """
    payload = {
        "pine_ids": [PUB_ID, PUB_ID, ...]
    }

    returns => {'pine_id': 'PUB;1fc1a95b23694a28892f3d1990e0168e', 
    'username': 'harjit91', 'hasAccess': True, 'noExpiration': False, 
    'currentExpiration': '2024-09-17T15:43:02.221181+00:00'}
    """
    url = URL_MAPPINGS_FOR_TRADINGVIEW_CODE["ACCESS"] + username
    try:
        pine_ids = payload["pine_ids"]
        tv = TradingView()
        accessList = []
        for pine_id in pine_ids:
            access = tv.get_access_details(username, pine_id)
            accessList.append(access)
        return accessList[0]
    except Exception:
        log(LogType.ERROR, traceback.format_exc(limit=1))
        return None

def post_access(username: str, payload: dict) -> list | None:
    """
    payload = {
        "pine_ids": [PUB_ID, PUB_ID, ...],
        "duration" : "7D"
    }

    returns => {'pine_id': 'PUB;1fc1a95b23694a28892f3d1990e0168e', 
    'username': 'harjit91', 
    'hasAccess': False, 
    'noExpiration': False, 
    'currentExpiration': '2024-09-16 15:43:02.221181+00:00', 
    'expiration': '2024-09-17 15:43:02.221181+00:00', 
    'status': 'Success'}
    """
    url = URL_MAPPINGS_FOR_TRADINGVIEW_CODE["ACCESS"] + username
    try:
        pine_ids = payload["pine_ids"]
        tv = TradingView()
        accessList = []
        for pine_id in pine_ids:
            access = tv.get_access_details(username, pine_id)
            accessList = accessList + [access]
        
        duration = payload['duration']
        dNumber = int(duration[:-1])
        dType = duration[-1:]
        for access in accessList:
            tv.add_access(access, dType, dNumber)
        if accessList[0]['status'] == 'Failure':
            return None
        print(accessList)
        return accessList[0]
    except Exception:
        log(LogType.ERROR, traceback.format_exc(limit=1))
        return None

def delete_access(username: str, payload: dict) -> list | None:
    """
    payload = {
        "pine_ids": [PUB_ID, PUB_ID, ...]
    }

    returns => {'pine_id': 'PUB;1fc1a95b23694a28892f3d1990e0168e', 
    'username': 'harjit91', 
    'hasAccess': True, 
    'noExpiration': False, 
    'currentExpiration': '2024-09-17T15:43:02.221181+00:00', 
    'status': 'Success'}
    """
    url = URL_MAPPINGS_FOR_TRADINGVIEW_CODE["ACCESS"] + username
    try:
        pine_ids = payload["pine_ids"]
        tv = TradingView()
        accessList = []
        for pine_id in pine_ids:
            access = tv.get_access_details(username, pine_id)
            accessList = accessList + [access]
        
        for access in accessList:
            tv.remove_access(access)
        return accessList[0]
    except Exception:
        log(LogType.ERROR, traceback.format_exc(limit=1))
        return None

# def get_instamojo_link(db_instance: Database, api_key: str, auth_token: str, payment_link: str | None, purpose: str, amount: float, buyer: str, email: str, phone: str, send_email: bool):

#     # * Get details of payment link using phone of subscriber
#     subscriber = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.PHONE: phone}, {"_id": 0, SUBSCRIBERS_TABLE.SUB_ID: 1, SUBSCRIBERS_TABLE.FULLNAME: 1, SUBSCRIBERS_TABLE.PHONE: 1})
#     payment = db_instance[TABLES.PAYMENT].find_one({PAYMENT_TABLE.SUB_ID: subscriber[SUBSCRIBERS_TABLE.SUB_ID]}, {"_id": 0, PAYMENT_TABLE.REQ_ID: 1, PAYMENT_TABLE.STATUS: 1}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])

#     if payment_link is not None:
#         if payment is None or payment[PAYMENT_TABLE.STATUS] in [PAYMENT_STATUS.COMPLETED, PAYMENT_STATUS.IGNORED]:
#             result = {
#                 "id": str(uuid.uuid4()),
#                 "success": True,
#                 "link": payment_link,
#                 "paid": False,
#                 "new" : True
#             }
#         else:
#             result = {
#                 "success": True,
#                 "id": payment[PAYMENT_TABLE.REQ_ID],
#                 "status": "Pending",
#                 "link": payment_link,
#                 "paid": False,
#                 "new" : False
#             }
#             if payment[PAYMENT_TABLE.STATUS] == PAYMENT_STATUS.COMPLETED:
#                 result["status"] = PAYMENT_STATUS.COMPLETED
#                 result["paid"] = True
#                 log(LogType.INFO, f"{buyer} has paid through the link, successfully")
#         return result
#     if payment is None or payment[PAYMENT_TABLE.STATUS] in [PAYMENT_STATUS.COMPLETED, PAYMENT_STATUS.IGNORED]:
#         result = generate_instamojo_link(api_key, auth_token, purpose, amount, buyer, email, phone, send_email)
#         if result["success"]:
#             log(LogType.INFO, f"Generated a payment link for {buyer} we got result {result}")
#         else:
#             log(LogType.ERROR, f"While generating a payment link for {buyer} we got an error result {result}")
#             db_instance[TABLES.FAILED].insert_one({FAILED_TABLE.PHONE: subscriber[SUBSCRIBERS_TABLE.PHONE], FAILED_TABLE.SUBSCRIBER_NAME: subscriber[SUBSCRIBERS_TABLE.FULLNAME], FAILED_TABLE.STRATEGY_NAME :STRATEGY_NAME, FAILED_TABLE.CREATED_TIME: datetime.now().strftime(DT_FORMAT), FAILED_TABLE.REASON: f"{result['message']}"})

#     else:
#         status = get_details_of_instamojo_link(api_key, auth_token, payment[PAYMENT_TABLE.REQ_ID])
#         if not status["paid"] and status["success"]:
#             enable_resp = enable_a_link(api_key, auth_token, payment[PAYMENT_TABLE.REQ_ID])
#             log(LogType.INFO, f"While trying to enable link for {buyer} we got result {'Success' if enable_resp else 'Failed'}")
#         elif status["paid"]:
#             log(LogType.INFO, f"{buyer} has paid through the link, successfully")
#         elif not status["success"]:
#             log(LogType.ERROR, f"Error while getting status of Instamojo Link. Message = {status['message']}")
#             db_instance[TABLES.FAILED].insert_one({FAILED_TABLE.PHONE: subscriber[SUBSCRIBERS_TABLE.PHONE], FAILED_TABLE.SUBSCRIBER_NAME: subscriber[SUBSCRIBERS_TABLE.FULLNAME], FAILED_TABLE.STRATEGY_NAME :STRATEGY_NAME, FAILED_TABLE.CREATED_TIME: datetime.now().strftime(DT_FORMAT), FAILED_TABLE.REASON: f"Error while getting status of Instamojo Link. Message = {status['message']}"})

#         result = status
#     return result

#     #* If payment link is active return same link | if inactive reactivate and send it | if no link generate_instamojo_link

# def check_and_update_payment_status(db_instance: Database, sub_id: str, instamojo_payment_link: str, reason: str):

#     #* db_instance[TABLES.PAYMENT].insert_one({PAYMENT_TABLE.LINK: instamojo_payment_link, PAYMENT_TABLE.USERNAME: to_name, PAYMENT_TABLE.STATUS: PAYMENT_STATUS.PENDING})
#     subscriber = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.SUB_ID: sub_id}, {"_id": 0, SUBSCRIBERS_TABLE.SUB_ID: 1, SUBSCRIBERS_TABLE.FULLNAME: 1, SUBSCRIBERS_TABLE.PHONE: 1})
#     # TODO: in case of new and paid grant access (for that build an endpoint for granting access)
#     if instamojo_payment_link["new"] and instamojo_payment_link["success"]:
#         log(LogType.SUCCESS, f"Created Payment for sub_id = {sub_id} Link and now storing it")
#         db_instance[TABLES.PAYMENT].insert_one({PAYMENT_TABLE.REQ_ID: instamojo_payment_link["id"], PAYMENT_TABLE.SUB_ID: sub_id, PAYMENT_TABLE.STATUS: PAYMENT_STATUS.PENDING, PAYMENT_TABLE.CREATED_TIME: datetime.now().strftime(DT_FORMAT), PAYMENT_TABLE.REASON: reason})
#     elif not instamojo_payment_link["new"] and instamojo_payment_link["success"]:
#         if instamojo_payment_link["paid"]:
#             log(LogType.SUCCESS, f"Payment was done for sub_id = {sub_id} storing it")
#         else:
#             log(LogType.INFO, f"Payment wasn't done for sub_id = {sub_id}")
#             db_instance[TABLES.PAYMENT].find_one_and_update({PAYMENT_TABLE.REQ_ID: instamojo_payment_link["id"]}, {"$set" : {PAYMENT_TABLE.REASON: reason}}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])
#     elif not instamojo_payment_link["success"]:
#         log(LogType.ERROR, f"There was a failure with Instamojo {instamojo_payment_link['message']}, {reason}")
#         db_instance[TABLES.FAILED].insert_one({FAILED_TABLE.PHONE: subscriber[SUBSCRIBERS_TABLE.PHONE], FAILED_TABLE.SUBSCRIBER_NAME: subscriber[SUBSCRIBERS_TABLE.FULLNAME], FAILED_TABLE.STRATEGY_NAME :STRATEGY_NAME, FAILED_TABLE.CREATED_TIME: datetime.now().strftime(DT_FORMAT), FAILED_TABLE.REASON: reason})


def validate_email(email_address):
    # Extract the domain from the email address
    domain = email_address.split('@')[-1]
    
    try:
        # Create a custom resolver with a longer timeout
        resolver = dns.resolver.Resolver()
        resolver.timeout = 10  # Increase timeout to 10 seconds
        resolver.lifetime = 10
        resolver.nameservers = ['8.8.8.8', '1.1.1.1']  # Use Google and Cloudflare DNS servers
        
        # Query MX records for the domain
        mx_records = resolver.resolve(domain, 'MX')
        return True if mx_records else False
    except dns.resolver.NoAnswer:
        print(f"No MX record found for domain: {domain}")
        return False
    except dns.resolver.NXDOMAIN:
        print(f"Domain does not exist: {domain}")
        return False
    except dns.exception.DNSException as e:
        print(f"DNS error: {e}")
        return False
    return False

# def send_email(from_email: str, to_email: str, to_name: str, subject: str, message: str = "", token: str = "", template_id: str = "", template_data: dict = {}, heading: str = "", style: str = "") -> bool:
#     url = "https://api.zeptomail.in/v1.1/email/template"


#     payload = {
#         "from": {
#             "address": from_email
#         },
#         "to": [
#             {
#                 "email_address": {
#                     "address": to_email,
#                     "name": to_name
#                 }
#             }
#         ],
#         "subject": subject,
#         # "htmlbody": f"<div><b> {message}  </b></div>"
#         "mail_template_key": template_id,  # Using the template ID
#         "merge_info": template_data
#     }

#     # with open("email.html", "r") as file:
#     #     Email_Message = file.read()
#     #     Email_Message = Email_Message.replace("{{EMAIL_MESSAGE}}", message)
#     #     Email_Message = Email_Message.replace("{{STYLE}}", style)
#     #     Email_Message = Email_Message.replace("{{HEADING}}", heading)
#     #     payload['htmlbody'] = Email_Message
#     #     file.close()
#     headers = {
#         'accept': "application/json",
#         'content-type': "application/json",
#         'authorization': f"Zoho-enczapikey {token}",
#     }

#     response = requests.request("POST", url, data=json.dumps(payload), headers=headers)
#     print(response.text)
#     if response.status_code == 200:
#         return True, "SUCCESS"
#     return False, response.text


# * ADMIN RELATED FUNCTIONS
def encrypt(text: str) -> str:
    """
    Encrypt the given string to hashed string\n
    """
    return fernet.encrypt(text.encode()).decode('utf-8')
    
def decrypt(text: str) -> str:
    """
    Decrypt the hashed string to original string\n
    """
    return fernet.decrypt(text.encode('utf-8')).decode()


def generate_api_key() -> str:
    return secrets.token_urlsafe(40).replace("_", "").replace("-", "")