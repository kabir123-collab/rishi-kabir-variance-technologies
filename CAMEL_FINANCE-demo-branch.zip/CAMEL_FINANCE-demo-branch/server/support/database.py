

import motor.motor_asyncio
from ..manager import url, DB_NAME
client = motor.motor_asyncio.AsyncIOMotorClient(url, uuidRepresentation="standard")
db = client[DB_NAME]