# Author	-	Karan Parmar

from .functions import generate_api_key

from datetime import datetime
from fastapi_users.db import BeanieBaseUser
from beanie import Document, PydanticObjectId

class User(BeanieBaseUser, Document):

	created_at: datetime = datetime.now()
	info: dict = {
		"name": "User",
		"api_key": generate_api_key(),
	}

models = [User, ]