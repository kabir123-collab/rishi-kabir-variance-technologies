from datetime import datetime, timedelta
from pymongo import DESCENDING
from pytz import timezone
from ..manager import DT_FORMAT, credentials, url, MongoClient, STRATEGY_NAME
# from ..manager import DT_FORMAT, RENEW_TEMPLATE, credentials, url, MongoClient, STRATEGY_NAME, MAIL_TOKEN, EMAIL_FROM, EMAIL_SEND, PAYMENT_LINK
from .enums import *
# from .functions import log, validate_email, send_email, get_instamojo_link, check_and_update_payment_status
from .functions import log

def check_expiry():
    """
        - will load all transactions that are not expired
        - if expiry < cur => expired
        - else continue
    """
    return
    db_instance = MongoClient(url)[credentials[CREDENTIALS_KEYS.DATABASE]]
    
    select_transactions = db_instance[TABLES.SUCCESS].find({SUCCESS_TABLE.EXPIRED: False})

    # if select_transactions is None or select_transactions:
    #     return
    for tran in select_transactions:

        subscriber_info = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.SUB_ID: tran[SUCCESS_TABLE.SUB_ID]})
        expiration = tran[SUCCESS_TABLE.EXPIRATION_TIMESTAMP]
        expiration_date = tran[SUCCESS_TABLE.EXPIRATION][:10]
        cur_timestamp = datetime.now(tz=timezone("UTC")).timestamp()
        warning_timestamp = expiration - (86400 * 5)

        if cur_timestamp >= expiration:
            db_instance[TABLES.SUCCESS].update_one({SUCCESS_TABLE.SUB_ID: tran[SUCCESS_TABLE.SUB_ID]}, {"$set": {SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT), SUCCESS_TABLE.EXPIRED: True}})
            db_instance[TABLES.SUBSCRIBERS].find_one_and_update({SUBSCRIBERS_TABLE.SUB_ID: tran[SUCCESS_TABLE.SUB_ID]}, {"$set": {SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.EXPIRED, SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
            db_instance[TABLES.PAYMENT].find_one_and_update({PAYMENT_TABLE.SUB_ID: tran[SUCCESS_TABLE.SUB_ID]}, {"$set": {PAYMENT_TABLE.STATUS: PAYMENT_STATUS.IGNORED}}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])
            log(LogType.INFO, f"Subscription for user = {subscriber_info[SUBSCRIBERS_TABLE.USERNAME]} is expired.")
            from_email = credentials["senders_email"]
            to_email = subscriber_info[SUBSCRIBERS_TABLE.EMAIL]
            to_name = subscriber_info[SUBSCRIBERS_TABLE.USERNAME]
            subject = "Expiration Email"
            message = f"Alert: subscription to {STRATEGY_NAME} for {subscriber_info[SUBSCRIBERS_TABLE.FULLNAME]}, has expired. We hope you enjoyed your time using this."
            token = MAIL_TOKEN
            # if EMAIL_SEND:
            #     if subscriber_info[SUBSCRIBERS_TABLE.EMAIL_VALID]:
            #         status = send_email(from_email, to_email, to_name, subject, message, token)
            #         if status:
            #             log(LogType.SUCCESS, f"Email sent successfully to {to_name} at {to_email}")
            #         else:
            #             log(LogType.ERROR, f"Email couldn't be sent to {to_name} at {to_email} contact support!")

            #     else:
            #         log(LogType.ERROR, f"Email couldn't be sent to {to_name} because email {to_email} is invalid")

        elif cur_timestamp >= warning_timestamp:
            from_email = EMAIL_FROM
            to_email = subscriber_info[SUBSCRIBERS_TABLE.EMAIL]
            to_name = subscriber_info[SUBSCRIBERS_TABLE.FULLNAME]

            log(LogType.INFO, f"Subscription for user = {to_name} is about to expire.")
            payment_doc = db_instance[TABLES.PAYMENT].find_one({PAYMENT_TABLE.SUB_ID: tran[SUCCESS_TABLE.SUB_ID]}, {"_id": 0, PAYMENT_TABLE.CREATED_TIME: 1}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])
            mailed_today = payment_doc[PAYMENT_TABLE.CREATED_TIME][:10] == datetime.now().strftime("%Y-%m-%d")
            instamojo_payment_link = get_instamojo_link(db_instance, credentials[CREDENTIALS_KEYS.INSTAMOJO_API], credentials[CREDENTIALS_KEYS.INSTAMOJO_AUTH], PAYMENT_LINK, "Renual Of Subscription", 0, to_name, to_email, subscriber_info[SUBSCRIBERS_TABLE.PHONE], EMAIL_SEND)
            subject = f"Your Access to {STRATEGY_NAME} is Expiring Soon!"
            template_id = RENEW_TEMPLATE
            template_data = {
                "fullname": subscriber_info[SUBSCRIBERS_TABLE.FULLNAME],
                "username": to_name,
                "expiration": expiration_date,
            }
            if EMAIL_SEND and not instamojo_payment_link["paid"] and instamojo_payment_link["success"] and not(mailed_today):
                if subscriber_info[SUBSCRIBERS_TABLE.EMAIL_VALID]:
                    status = send_email(from_email, to_email, to_name, subject, token=MAIL_TOKEN, template_id=template_id, template_data=template_data)
                    if status:
                        log(LogType.SUCCESS, f"Email sent successfully to {to_name} at {to_email}")
                        reason = "Mail sent"
                    else:
                        log(LogType.ERROR, f"Email couldn't be sent to {to_name} at {to_email} contact support!")
                        reason = "Mail couldn't be sent"

                else:
                    log(LogType.ERROR, f"Email couldn't be sent to {to_name} because email {to_email} is invalid")
                    reason = "Invalid mail"
            elif instamojo_payment_link["paid"]:
                reason = "Payment Done"
            elif not instamojo_payment_link["success"]:
                reason = "Couldn't get link"
            else:
                reason = "Don't want to send mail"

            check_and_update_payment_status(db_instance, tran[SUBSCRIBERS_TABLE.SUB_ID], instamojo_payment_link, reason)
