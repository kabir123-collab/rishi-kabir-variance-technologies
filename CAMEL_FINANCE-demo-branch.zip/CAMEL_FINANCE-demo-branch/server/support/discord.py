"""
Sends alerts to discord channel via webhook
There is no need to authenticate to discord as it only requires webhook

- send text alert
- send embed alert
- send file
"""

# Importing built-in libraries
import threading

# Importing third-party libraries
from dhooks import Webhook, Embed, File

class DiscordAlert:

        _colors = {
                "green" : 0x2ECC71,
                "red" : 0xE74C3C,
                "gold" : 0xF1C40F,
                "yellow" : 0xFFFF00,
                "blue" : 0x3498DB,
                "pink" : 0xFD0061,
        }
        _default_color = "pink"
        _white_list = ["all"]

        # Private methods
        def _send_text_alert(self, webhook_url:str, message:str, author:str) -> None:
                """
                Sends text alert to discord\n
                """
                try:
                        hook = Webhook(webhook_url)
                        kwargs = {}
                        if author != ...:
                                kwargs.update({"username":author})
                        threading.Thread(target=hook.send, args=(str(message),), kwargs=kwargs).start()
                except Exception as e:
                        ...

        def _send_embed_alert(self, webhook_url:str, message:dict, author:str, title:str=None, description:str=None) -> None:
                """
                Sends embed alert to webhook\n
                """
                options = {
                        "color" : self._colors[message['color']] if message.get('color') else self._colors[self._default_color],
                        "timestamp" : "now"
                }
                if title is not None: options['title'] = title
                if description is not None: options['description'] = description
                embed = Embed(**options)

                for k,v in message.items():
                        if 'all' in self._white_list:
                                embed.add_field(name=k.upper(), value=str(v), inline=False)

                        elif k in self._white_list:
                                embed.add_field(name=k.upper(), value=str(v), inline=False)

                try:
                        hook = Webhook(webhook_url)
                        kwargs = {"embed":embed}
                        if author != ...:
                                embed.set_author(name=author)
                                kwargs.update({"username":author})
                        threading.Thread(target=hook.send, kwargs=kwargs).start()
                except Exception as e:
                        ...

        # Public methods
        def set_white_list(self, white_list:list) -> None:
                """
                Sets white list for embed params\n
                """
                self._white_list = white_list

        def send_alert(self, webhook_url:str, author:str=..., message:dict=..., use_embed:bool=True) -> None:
                """
                Send embed and text alert to webhook\n
                """
                # Sends embed alert
                if use_embed:
                        title, description = None, None

                        if 'title' in message:
                                title = message['title']
                                del message['title']

                        if 'description' in message:
                                description = message['description']
                                del message['description']

                        self._send_embed_alert(webhook_url=webhook_url, message=message, author=author, title=title, description=description)

                # Sends text alert
                else:
                        self._send_text_alert(webhook_url=webhook_url, message=message, author=author)

        def send_file(self, webhook_url:str, file_to_send:object, file_name:str=..., author:str=...) -> None:
                """
                Send file to discord webhook\n
                """
                try:
                        hook = Webhook(webhook_url)

                        _file = File(file_to_send, name=file_name)
                        kwargs = {"file":_file}
                        if author != ...:
                                kwargs.update({"username":author})
                        threading.Thread(target=hook.send, kwargs=kwargs).start()

                except Exception as e:
                        print(e)
# if __name__ == "__main__":

#       a1 = DiscordAlert()

#       webhook_url = "https://discord.com/api/webhooks/1205198518239629442/5e-CAmyxxZHnU9iHgjO770_C7XLyAAaF5RJxbgc6qQ7fj3uhRHjrgwLJzuyj31Gb8Sah"

#       # NOTE Send text and embed alert to discord channel using thread
#       message = {
#               "title":"Test alert",
#               "description":"This is dummy alert",
#       }
#       a1.send_alert(webhook_url=webhook_url, message=message, use_embed=True)

#       # NOTE Send file to discord channel using thread
#       with open("collected_data.csv","rb") as f:
#               file_name = "collected_data.csv"
#               a1.send_file(webhook_url=webhook_url, file_to_send=f, file_name=file_name)
#               f.close()
