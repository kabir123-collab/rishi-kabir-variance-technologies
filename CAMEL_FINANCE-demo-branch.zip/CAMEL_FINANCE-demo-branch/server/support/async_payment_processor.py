from datetime import datetime
import uuid
from .functions import post_access
from .enums import *
import asyncio
from ..manager import task_queue, STRATEGY_NAME, PUB_ID, db_instance, LogType, log, DT_FORMAT
from pymongo import DESCENDING
from .schemas import FAILED
from ..support.discord import DiscordAlert

a = DiscordAlert()
webhook_url = "https://discord.com/api/webhooks/1339187780055470080/PTnXEm5fnDtcQDImML8TipCt19IjTvL6p9-TQmNYs6fWtBIoc-ABoW7VRFmq_5ffhEpm"


async def process_payment(parsed_data, number_of_days, sub_id, new_user, sleep_time):
    email = parsed_data["email"]
    doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: email}, 
                                                    {"_id": 0})
    payment_id = parsed_data["payment_id"]
    amount = parsed_data["amount"]
    currency = parsed_data["currency"]
    payment_type = parsed_data["subscription_type"]
    tv_username = doc[SUBSCRIBERS_TABLE.USERNAME]
    payment_category = parsed_data["payment"]
    buyer_name = doc[SUBSCRIBERS_TABLE.FULLNAME]

    access_status = post_access(tv_username, payload={"pine_ids": [PUB_ID], "duration": f"{number_of_days}D"})
    if access_status is None:
        reason = f"PAYMENT, Issue while granting access to user = {tv_username}, email = {email}, amount = {amount}, payment_id = {payment_id} for strategy_name = {STRATEGY_NAME} check with backend."
        failed = FAILED(doc[SUBSCRIBERS_TABLE.EMAIL], doc[SUBSCRIBERS_TABLE.FULLNAME], STRATEGY_NAME, create_time=datetime.now().strftime(DT_FORMAT), reason=reason)
        db_instance[TABLES.FAILED].insert_one(failed.to_dict())
        log(LogType.ERROR, reason)
        
        # add discord alert for failure
        message = {
            "title":f"{datetime.now()}_FAILURE",
            "description":f"PAYMENT, Issue while granting access to user because of incorrect tv_username = {tv_username}, email = {email}, amount = {amount}, payment_id = {payment_id} for strategy_name = {STRATEGY_NAME} check with backend. Issue with TV_NAME.",
        }
        try:
            a.send_alert(webhook_url=webhook_url, message=message, use_embed=True)
        except:
            ...
        await asyncio.sleep(int(sleep_time))  # Equal intervals using asyncio.sleep()
        return
    else:
        db_instance[TABLES.SUBSCRIBERS].find_one_and_update({SUBSCRIBERS_TABLE.SUB_ID: sub_id}, {"$set": {SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.ACTIVE, 
                                                                                                            SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
        log(LogType.SUCCESS, f"Successfully granted access for {number_of_days} Days to user {tv_username}, email = {email}")
        
        expiration = access_status["expiration"]
        expiration_timestamp = datetime.strptime(access_status["expiration"], "%Y-%m-%d %H:%M:%S.%f%z").timestamp()
        
        if not new_user:
            db_instance[TABLES.SUCCESS].find_one_and_update({SUCCESS_TABLE.SUB_ID: sub_id}, {"$set": {SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
                                                                                                    SUCCESS_TABLE.EXPIRATION: expiration, 
                                                                                                    SUCCESS_TABLE.EXPIRATION_TIMESTAMP: expiration_timestamp, 
                                                                                                    SUCCESS_TABLE.EXPIRED: False,
                                                                                                    SUCCESS_TABLE.PAYMENT_TYPE: payment_category,
                                                                                                    SUCCESS_TABLE.SUBSCRIPTION_TYPE: payment_type}})
        else:
            insert = {
                SUCCESS_TABLE.SUB_ID: sub_id,
                SUCCESS_TABLE.CREATE_TIME: datetime.now().strftime(DT_FORMAT),
                SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
                SUCCESS_TABLE.EXPIRATION: expiration,
                SUCCESS_TABLE.EXPIRATION_TIMESTAMP: expiration_timestamp,
                SUCCESS_TABLE.EXPIRED: False,
                SUCCESS_TABLE.PAYMENT_TYPE: payment_category,
                SUCCESS_TABLE.SUBSCRIPTION_TYPE: payment_type
            }
            db_instance[TABLES.SUCCESS].insert_one(insert)
                                                                                                    
        log(LogType.SUCCESS, f"Added data to Success table")

    pay_doc = db_instance[TABLES.PAYMENT].find_one({PAYMENT_TABLE.SUB_ID: sub_id}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])

    if pay_doc is not None and pay_doc[PAYMENT_TABLE.STATUS] != PAYMENT_STATUS.COMPLETED:
        db_instance[TABLES.PAYMENT].find_one_and_update({PAYMENT_TABLE.SUB_ID: sub_id}, {"$set": {PAYMENT_TABLE.STATUS: PAYMENT_STATUS.COMPLETED,
                                                                                                      PAYMENT_TABLE.REASON: "Payment Done", 
                                                                                                      PAYMENT_TABLE.PAYMENT_ID: payment_id, 
                                                                                                      PAYMENT_TABLE.PAYED_TIME: parsed_data["payment_time"],
                                                                                                      PAYMENT_TABLE.AMOUNT: amount, 
                                                                                                      PAYMENT_TABLE.FEE: 0, 
                                                                                                      PAYMENT_TABLE.CURRENCY: currency}}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])
        
    else:
        reason = f"PAYMENT, Person {buyer_name} with sub_id = {sub_id} did the payment of {amount} in {currency}, when no payment was pending. Payment ID = {payment_id}, {email}"
        log(LogType.INFO, reason)
        db_instance[TABLES.PAYMENT].insert_one({PAYMENT_TABLE.REQ_ID: str(uuid.uuid4()), 
                                                PAYMENT_TABLE.SUB_ID: sub_id, 
                                                PAYMENT_TABLE.STATUS: PAYMENT_STATUS.COMPLETED, 
                                                PAYMENT_TABLE.CREATED_TIME: datetime.now().strftime(DT_FORMAT), 
                                                PAYMENT_TABLE.REASON: reason,
                                                PAYMENT_TABLE.PAYMENT_ID: payment_id, 
                                                PAYMENT_TABLE.PAYED_TIME: parsed_data["payment_time"],
                                                PAYMENT_TABLE.AMOUNT: amount, 
                                                PAYMENT_TABLE.FEE: 0, 
                                                PAYMENT_TABLE.CURRENCY: currency})
        log(LogType.INFO, f"Successfully saved payment info for sub_id = {sub_id}, email = {email}, tv_username = {tv_username}")
    
    # add success log to discord
    message = {
            "title":f"{datetime.now()}_SUCCESS",
            "description":f"Successfully saved payment info for sub_id = {sub_id}, email = {email}, tv_username = {tv_username}, number_of_days = {number_of_days}, \n\npayload = {parsed_data}",
    }
    try:
        a.send_alert(webhook_url=webhook_url, message=message, use_embed=True)
    except:
        ...
   
    await asyncio.sleep(int(sleep_time))  # Equal intervals using asyncio.sleep()



async def worker(task_queue):
    while True:
        if not task_queue.empty():
            task = await task_queue.get()
            await process_payment(**task)
        else:
            print("waiting because task_queue empty")
            await asyncio.sleep(10)


async def run_task_manager():
    await worker(task_queue)

try:
    loop = asyncio.get_running_loop()
    loop.create_task(run_task_manager())  # Create a task in the existing loop
except RuntimeError:
    asyncio.run(run_task_manager())