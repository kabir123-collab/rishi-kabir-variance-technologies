

class LogType:

    INFO = "info"
    ERROR = "error"
    SUCCESS = "success"

class CREDENTIALS_KEYS:

    DATABASE = "database"
    HOST = "host_ip"
    DB_UNAME = "db_username"
    DB_PASSWORD = "db_password"
    
    INSTAMOJO_API = "instamojo_api_key"
    INSTAMOJO_AUTH = "instamojo_auth_token"

    STRATEGY_NAME = "strategy_name"
    STRATEGY_PUBID = "strategy_pubid"
    RENEWAL_AMOUNT = "renewal_amount"
    PAYMENT_LINK = "payment_link"
    
    CLASSPLUS_TOKEN = "class_plus_token"
    
    ADMIN_USERNAME = "admin_username"
    ADMIN_EMAIL = "admin_email"
    ADMIN_PASSWORD = "admin_password"
    ADMIN_TOKEN = "admin_token"
    
    MAIL_TOKEN = "mail_token"
    SUBSCRIBE_TEMPLATE = "subscribe_mail_template"
    RENEW_TEMPLATE = "renewal_mail_template"
    SEND_EMAIL = "send_email"
    SENDERS_EMAIL = "senders_email"


class TABLES:

    ADMIN = "ADMIN"
    SUBSCRIBERS = "SUBSCRIBERS"
    PAYMENT = "PAYMENT"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"

class ADMIN_TABLE:

    USERNAME = "username"
    PASSWORD = "password"
    TOKEN = "token"

class SUBSCRIBERS_TABLE:

    SUB_ID = "subid"
    CREATED_TIME = "created_time"
    LAST_UPDATED = "last_updated_time"
    FULLNAME = "fullname"
    USERNAME = "username"
    EMAIL = "email"
    EMAIL_VALID = "email_valid"
    STATUS = "status"

class SUBSCRIBER_STATUS:

    NO_ACCESS = "no_access_could_be_provided"
    ACTIVE = "active"
    NEW = "new"
    EXPIRED = "expired"

class PAYMENT_TABLE:

    REQ_ID = "request_id"
    SUB_ID = "subid"
    STATUS = "status"
    CREATED_TIME = "created_time"
    PAYMENT_ID = "payment_id"
    PAYED_TIME = "payed_time"
    AMOUNT = "amount"
    FEE = "fee"
    CURRENCY = "currency"
    REASON = "reason"

class PAYMENT_STATUS:

    PENDING = "Sent"
    COMPLETED = "Completed"
    IGNORED = "ignored"

class SUCCESS_TABLE:

    SUB_ID = "subid"
    CREATE_TIME = "create_time"
    LAST_UPDATED_TIME = "last_updated_time"
    EXPIRATION = "expiration"
    EXPIRATION_TIMESTAMP = "expiration_timestamp"
    EXPIRED = "expired"
    PAYMENT_TYPE = "payment_type"
    SUBSCRIPTION_TYPE = "subs_type"

class FAILED_TABLE:
    
    SUBSCRIBER_NAME = "sub_name"
    STRATEGY_NAME = "strategy_name"
    CREATED_TIME = "create_time"
    REASON = "reason"
    EMAIL = "email"