
from typing import Optional
from typing_extensions import Unpack
from pydantic import BaseModel, ConfigDict, Field
from fastapi_users import schemas
from beanie import PydanticObjectId

class UserRead(schemas.BaseUser[PydanticObjectId]):
	
	email : str
	info: dict


class UserCreate(schemas.BaseUserCreate):
	pass


class UserUpdate(schemas.BaseUserUpdate):
	pass


# User info
class UpdateUserInfo(BaseModel):
	
	name : Optional[str]

	def to_dict(self) -> dict:
		data = {}

		if self.name:
			data['name'] = self.name
		
		return data

class StrategyAdd(BaseModel):

	strategy_name: str = None
	pub_id: str = None
      
class StrategyEdit(BaseModel):

	strategy_name: str = None
	new_pub_id: str = None

class StrategyDeactivate(BaseModel):

	strategy_name: str = None
	
class Admin(BaseModel):
	
    username: str
    password: str

class Subscribe(BaseModel):
     
    username: str
    duration: str
    userphone: str

class InstaMojoPayment(BaseModel):
      
    payment_url: str = None
    status: str = None


class PaymentFilter(BaseModel):

    status: str = "all" #NOTE -> possible values => ["all", "success", "failed"]

class UserbaseFilter(BaseModel):
    
    status: str = "all" #NOTE -> possible values => ["all", "new", "active", "expired"]

class GrantAccess(BaseModel):
      
    email: str
    tradingview_username: str
    days: int

class RevokeAccess(BaseModel):
      
    email: str
    tradingview_username: str

class AddUser(BaseModel):
     
    number_of_days: int = None
    tradingview_username: str = None
    email: str = None
    fullname: str = None

class RemoveUser(BaseModel):
     
    email: str = None

class UpdateUser(BaseModel):
     
    email: str = None

    update_fullname: Optional[str]
    update_tradingview_username: Optional[str]

class FAILED:

    email: str = None
    sub_name: str = None
    strategy_name: str = None
    create_time: str = None
    reason: str = None

    def __init__(self, email, sub_name,strategy_name,create_time,reason):
        self.email = email
        self.sub_name = sub_name
        self.strategy_name = strategy_name
        self.create_time = create_time
        self.reason = reason
        

    def to_dict(self):
        return {
            "email": self.email,
            "sub_name": self.sub_name,
            "strategy_name": self.strategy_name,
            "create_time": self.create_time,
            "reason": self.reason,
        }
    
class SUCCESS:
     
    subid: str = None
    create_time: str = None
    last_updated_time: str = None
    expiration: str = None
    expiration_timestamp: int = None
    expired: bool = False

    def __init__(self, subid, create_time, last_updated_time, expiration, expiration_timestamp, expired):
        self.subid = subid
        self.create_time = create_time
        self.last_updated_time = last_updated_time
        self.expiration = expiration
        self.expiration_timestamp = expiration_timestamp
        self.expired = expired
        

    def to_dict(self):
        return {
            "subid": self.subid,
            "create_time": self.create_time,
            "last_updated_time": self.last_updated_time,
            "expiration": self.expiration,
            "expiration_timestamp": self.expiration_timestamp,
            "expired": self.expired
        }