from datetime import datetime
import json
import uuid
from fastapi import APIRouter, Request
from pymongo import DESCENDING
from ..manager import db_instance, LogType, log, DT_FORMAT, task_queue
from ..support.enums import *
from ..support.functions import create_subscriber
from ..support.discord import DiscordAlert

PAYMENT_AMOUNT_MAPPINGS = {
    "months": 30,
    "years": 365
}
a1 = DiscordAlert()

# webhook_url = "https://discord.com/api/webhooks/1306689076698681414/MVyy9apqrul-OFYfSIirbshvvkyavfE_vUxRvK90xPl2skf_MwgHNssXo1qsUXE5fsgf" #* change back after demo
webhook_url = "https://discord.com/api/webhooks/1338459986564616214/8lvm2kp6ejgCNEC1YIGm0yHnogJNFQyPEyyDgAhRcrOgeXJ8t0_V1s5__jAVk51SphTN"


router = APIRouter(prefix='/payment', tags=['payment'])

@router.post("/payment-callback")
async def recieve_payment(request: Request):
    """
        Takes the payment data and grants access and updates the db

        {"payment_id": "Error: No transaction found for this subscription.",
        "amount": 0,
        "platform_fee": 0,
        "currency": "USD",
        "payment_time": "",
        "email": "Dina66@yopmail.com",
        "tradingview_username": "Dina66test44",
        "payment": "NEW",
        "subscription_type": "months"}
    """
    with open("credentials.json") as file:
        data = json.load(file)
        file.close()
    DEMO_DAYS = data["demo_days"]
    SLEEP_TIME = data["sleep_time"]

    parsed_data = await request.json()

    # Send discord alert
    message = {
            "title":f"{datetime.now()}",
            "description":str(parsed_data),
    }
    try:
        a1.send_alert(webhook_url=webhook_url, message=message, use_embed=True)
    except:
        ...
    log(LogType.INFO, f"PAYMENT, Recieved the status from Paypal = {parsed_data}")

    email = parsed_data["email"]
    doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: email}, 
                                                    {"_id": 0})
    if parsed_data["payment"] == "CANCEL":
        if doc is not None:
            sub_id = doc[SUBSCRIBERS_TABLE.SUB_ID]
            db_instance[TABLES.SUBSCRIBERS].find_one_and_update({SUBSCRIBERS_TABLE.SUB_ID: sub_id}, {"$set": {SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT),
                                                                                                              SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.EXPIRED}})
            db_instance[TABLES.SUCCESS].find_one_and_update({SUCCESS_TABLE.SUB_ID: sub_id}, {"$set": {SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
                                                                                                    SUCCESS_TABLE.EXPIRED: True}})
        return {"data" : "success"}

    if parsed_data["payment_id"] == "Error: No transaction found for this subscription.":
        parsed_data["payment_id"] = str(uuid.uuid4())

    payment_id = parsed_data["payment_id"]
    payment_type = parsed_data["subscription_type"]
    tv_username = parsed_data["tradingview_username"]
    payment_category = parsed_data["payment"]
    number_of_days = PAYMENT_AMOUNT_MAPPINGS[payment_type]

    new_user = False
    if doc is None:
        new_user = True
        reason = f"PAYMENT, No user found with the email = {email}. Data = {parsed_data}. So creating one."
        log(LogType.ERROR, reason)

        sub_id = str(uuid.uuid4())
        create_subscriber(db_instance, sub_id, email, tv_username, tv_username)
        doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: email}, 
                                                       {"_id": 0})
        log(LogType.SUCCESS, f"Created new user and providing DEMO Access for {DEMO_DAYS} days. Email: {email}, tv_username: {tv_username}, doc: {doc}")
        number_of_days = DEMO_DAYS 
    else:
        sub_id = doc[SUBSCRIBERS_TABLE.SUB_ID]

        pay_doc = db_instance[TABLES.PAYMENT].find_one({PAYMENT_TABLE.SUB_ID: sub_id}, sort=[(PAYMENT_TABLE.CREATED_TIME, DESCENDING)])
        success_doc = db_instance[TABLES.SUCCESS].find_one({SUCCESS_TABLE.SUB_ID: sub_id}, {"_id": 0})
        if pay_doc is not None and\
           pay_doc[PAYMENT_TABLE.PAYED_TIME] == parsed_data["payment_time"] and\
           success_doc is not None and success_doc[SUCCESS_TABLE.PAYMENT_TYPE] == payment_category and success_doc[SUCCESS_TABLE.SUBSCRIPTION_TYPE] == payment_type:
            log(LogType.INFO, f"Recieved data again for subid {sub_id}")
            return {"data": "failure", "message": f"Recieved data again for subid {sub_id}", "status": 400}
    
    # Add task to queue
    await task_queue.put({"parsed_data": parsed_data, "number_of_days": number_of_days, "sub_id": sub_id, "new_user": new_user, "sleep_time": SLEEP_TIME})
    return {"data": "success"}