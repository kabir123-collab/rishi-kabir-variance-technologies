# Author	-	Karan Parmar


from datetime import datetime, timedelta
import json
import uuid

import pytz
from ..support.models import User
from ..user_manager import current_active_user
from ..manager import db_instance, STRATEGY_NAME, DT_FORMAT, LogType, log, STRATEGY_NAME, PUB_ID
from ..support.enums import *
from ..support.schemas import GrantAccess, RevokeAccess, AddUser, RemoveUser, UpdateUser, FAILED
from ..support.functions import post_access, delete_access, verify_user, create_subscriber

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

PAGE = 50

router = APIRouter(prefix="/admin", tags=['admin'])

@router.get("/failed")
async def get_failed(page: int = 1, search: str = "", user: User = Depends(current_active_user)) -> JSONResponse:
	"""
	"""
	if user is None:
		return JSONResponse({"error": "Unauthorized"}, 401)
	fields = [FAILED_TABLE.SUBSCRIBER_NAME, FAILED_TABLE.REASON]
	page -= 1
	search_filter = {} if search == "" else {
											"$or": [
												{field: {"$regex": search, "$options": "i"}} for field in fields
											]
										}
	failed = db_instance[TABLES.FAILED].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(FAILED_TABLE.CREATED_TIME, -1)])
	count = db_instance[TABLES.FAILED].count_documents({})
	return {"data": list(failed), "count": count}

@router.get("/payment")
async def get_payments(status: str, page: int = 1, search: str = "", user: User = Depends(current_active_user)) -> JSONResponse:
	"""
        /payment/{type} -> type => [PENDING, COMPLETED, IGNORED]
	"""
	if user is None:
		return JSONResponse({"error": "Unauthorized"}, 401)
	
	if status.upper() not in ["PENDING", "COMPLETED", "IGNORED"]:
		return JSONResponse({"error": "Invalid Status provided, use [PENDING, COMPLETED, IGNORED]"}, 401)
	page -= 1

	fields = [PAYMENT_TABLE.REASON, PAYMENT_TABLE.STATUS]
	if search == "":
		search_filter = {}  
	else:
		matching_subscribers = db_instance[TABLES.SUBSCRIBERS].find(
				{SUBSCRIBERS_TABLE.FULLNAME: {"$regex": search, "$options": "i"}},
				{"_id": 0, SUBSCRIBERS_TABLE.SUB_ID: 1}
			)
		matching_sub_ids = [sub[SUBSCRIBERS_TABLE.SUB_ID] for sub in matching_subscribers]
		search_filter = {
			"$or": [
				{PAYMENT_TABLE.SUB_ID: {"$in": matching_sub_ids}},
				*[{field: {"$regex": search, "$options": "i"}} for field in fields]
			]
		}
	if status.upper() == "PENDING":
		search_filter[PAYMENT_TABLE.STATUS] = PAYMENT_STATUS.PENDING
		payments = db_instance[TABLES.PAYMENT].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(PAYMENT_TABLE.CREATED_TIME, -1)])
		count = db_instance[TABLES.PAYMENT].count_documents({PAYMENT_TABLE.STATUS: PAYMENT_STATUS.PENDING})
	elif status.upper() == "COMPLETED":
		search_filter[PAYMENT_TABLE.STATUS] = PAYMENT_STATUS.COMPLETED
		payments = db_instance[TABLES.PAYMENT].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(PAYMENT_TABLE.CREATED_TIME, -1)])
		count = db_instance[TABLES.PAYMENT].count_documents({PAYMENT_TABLE.STATUS: PAYMENT_STATUS.COMPLETED})
	else:
		search_filter[PAYMENT_TABLE.STATUS] = PAYMENT_STATUS.IGNORED
		payments = db_instance[TABLES.PAYMENT].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(PAYMENT_TABLE.CREATED_TIME, -1)])
		count = db_instance[TABLES.PAYMENT].count_documents({PAYMENT_TABLE.STATUS: PAYMENT_STATUS.IGNORED})

	subs = {}
	result = []
	for i in payments:
		if i[PAYMENT_TABLE.SUB_ID] not in subs:
			subs[i[PAYMENT_TABLE.SUB_ID]] = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.SUB_ID: i[PAYMENT_TABLE.SUB_ID]}, {"_id": 0, SUBSCRIBERS_TABLE.FULLNAME: 1})[SUBSCRIBERS_TABLE.FULLNAME]
		
		i[SUBSCRIBERS_TABLE.FULLNAME] = subs[i[PAYMENT_TABLE.SUB_ID]]
		result.append(i)
	return {"data": result, "count": count}

@router.get("/all")
async def get_users(status: str, page: int = 1, search: str = "", user: User = Depends(current_active_user)) -> JSONResponse:
	"""
        /all/{type} -> type => [ACTIVE, INACTIVE, DEMO]
	"""
	if user is None:
		return JSONResponse({"error": "Unauthorized"}, 401)
	
	if status.upper() not in ["ACTIVE", "INACTIVE", "DEMO"]:
		return JSONResponse({"error": "Invalid Status provided, use [ACTIVE, INACTIVE, DEMO]"}, 401)
	page -= 1
	fields = [SUBSCRIBERS_TABLE.EMAIL, SUBSCRIBERS_TABLE.EMAIL_VALID, SUBSCRIBERS_TABLE.FULLNAME, SUBSCRIBERS_TABLE.STATUS, SUBSCRIBERS_TABLE.USERNAME]
	search_filter = {} if search == "" else  {
														"$or": [
															{field: {"$regex": search, "$options": "i"}} for field in fields
														]
													}
	if status.upper() == "ACTIVE":
		search_filter[SUBSCRIBERS_TABLE.STATUS] = SUBSCRIBER_STATUS.ACTIVE
		users = db_instance[TABLES.SUBSCRIBERS].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(SUBSCRIBERS_TABLE.CREATED_TIME, -1)])
		count = db_instance[TABLES.SUBSCRIBERS].count_documents({SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.ACTIVE})
	elif status.upper() == "INACTIVE":
		search_filter[SUBSCRIBERS_TABLE.STATUS] = {"$in": [SUBSCRIBER_STATUS.EXPIRED, SUBSCRIBER_STATUS.NO_ACCESS]}
		users = db_instance[TABLES.SUBSCRIBERS].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(SUBSCRIBERS_TABLE.CREATED_TIME, -1)])
		count = db_instance[TABLES.SUBSCRIBERS].count_documents({SUBSCRIBERS_TABLE.STATUS: {"$in": [SUBSCRIBER_STATUS.EXPIRED, SUBSCRIBER_STATUS.NO_ACCESS]}})
	else:
		search_filter[SUBSCRIBERS_TABLE.STATUS] = SUBSCRIBER_STATUS.NEW
		users = db_instance[TABLES.SUBSCRIBERS].find(search_filter, {"_id": 0}, skip =  PAGE * page, limit = PAGE).sort([(SUBSCRIBERS_TABLE.CREATED_TIME, -1)])
		count = db_instance[TABLES.SUBSCRIBERS].count_documents({SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.NEW})
	
	result = []
	for i in users:
		success_data = db_instance[TABLES.SUCCESS].find_one({SUCCESS_TABLE.SUB_ID: i[SUBSCRIBERS_TABLE.SUB_ID]}, {"_id": 0, SUCCESS_TABLE.LAST_UPDATED_TIME: 1, SUCCESS_TABLE.EXPIRATION_TIMESTAMP: 1, SUCCESS_TABLE.EXPIRATION: 1, SUCCESS_TABLE.PAYMENT_TYPE: 1, SUCCESS_TABLE.SUBSCRIPTION_TYPE: 1})
		if success_data is not None:
			last_updated_success_time = success_data[SUCCESS_TABLE.LAST_UPDATED_TIME]
			subs_last_updated_time    = i[SUBSCRIBERS_TABLE.LAST_UPDATED]

			i[SUBSCRIBERS_TABLE.LAST_UPDATED] = max(last_updated_success_time, subs_last_updated_time)
			i[SUCCESS_TABLE.PAYMENT_TYPE] = success_data[SUCCESS_TABLE.PAYMENT_TYPE]
			i[SUCCESS_TABLE.SUBSCRIPTION_TYPE] = success_data[SUCCESS_TABLE.SUBSCRIPTION_TYPE]
			if i[SUBSCRIBERS_TABLE.STATUS] != SUBSCRIBER_STATUS.EXPIRED:
				now_timestamp = datetime.now(tz=pytz.timezone("UTC")).timestamp()
				days_to_expire = success_data[SUCCESS_TABLE.EXPIRATION_TIMESTAMP] - now_timestamp
				print(success_data[SUCCESS_TABLE.EXPIRATION_TIMESTAMP], now_timestamp)
				if days_to_expire >= 0:
					i["days_to_expire"] = int(days_to_expire / 86400)
				else:
					i["days_to_expire"] = 0
			else:
				i["experation"] = success_data[SUCCESS_TABLE.EXPIRATION]
		result.append(i)
	return {"data": result, "count": count}

@router.get("/numbers")
async def get_all_counts(user: User = Depends(current_active_user)) -> JSONResponse:
	"""
        returns a dict with all the count of each of the required params:
		{
			"active": x,
			"inactive": x,
			"demo": x,
			"payment_pending": x,
			"payment_completed": x,
			"payment_ignored": x,
			"failures": x,
		}
	"""
	if user is None:
		return JSONResponse({"error": "Unauthorized"}, 401)
	
	result = {
		"active": db_instance[TABLES.SUBSCRIBERS].count_documents({SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.ACTIVE}),
		"inactive": db_instance[TABLES.SUBSCRIBERS].count_documents({SUBSCRIBERS_TABLE.STATUS: {"$in": [SUBSCRIBER_STATUS.EXPIRED, SUBSCRIBER_STATUS.NO_ACCESS]}}),
		"demo": db_instance[TABLES.SUBSCRIBERS].count_documents({SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.NEW}),
		"payment_pending": db_instance[TABLES.PAYMENT].count_documents({PAYMENT_TABLE.STATUS: PAYMENT_STATUS.PENDING}),
		"payment_completed": db_instance[TABLES.PAYMENT].count_documents({PAYMENT_TABLE.STATUS: PAYMENT_STATUS.COMPLETED}),
		"payment_ignored": db_instance[TABLES.PAYMENT].count_documents({PAYMENT_TABLE.STATUS: PAYMENT_STATUS.IGNORED}),
		"success": db_instance[TABLES.SUCCESS].count_documents({}),
		"failures": db_instance[TABLES.FAILED].count_documents({}),
	}
	return {"data": result}


@router.post("/grant-access")
async def give_access_to(data: GrantAccess, user: User = Depends(current_active_user)) -> JSONResponse:
	"""
		data = {
			tradingview_username: str
		}
	"""
	if user is None:
		return JSONResponse({"error": "Unauthorized"}, 401)
	
	doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: data.email}, {"_id": 0})
	if doc is None:
		return JSONResponse({"error": f"No Data found with given Email {data.email}"}, 401)
	tradingview_username = doc[SUBSCRIBERS_TABLE.USERNAME]
	access_status = post_access(tradingview_username, {"pine_ids": [PUB_ID], "duration": f"{data.days}D"})
	if access_status is None:
		reason = f"Issue while granting access to email = {data.email}, user = {tradingview_username} for strategy_name = {STRATEGY_NAME} check with backend. BY_ADMIN"
		failed = FAILED(doc[SUBSCRIBERS_TABLE.EMAIL],
				  doc[SUBSCRIBERS_TABLE.FULLNAME], 
				  STRATEGY_NAME, 
				  create_time=datetime.now().strftime(DT_FORMAT), 
				  reason=reason)
		db_instance[TABLES.FAILED].insert_one(failed.to_dict())
		log(LogType.ERROR, reason)

		db_instance[TABLES.SUBSCRIBERS].update_one({SUBSCRIBERS_TABLE.EMAIL: data.email}, {"$set": {SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.NO_ACCESS, SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
		return JSONResponse({"error": reason}, status_code=400)
	else:
		db_instance[TABLES.SUBSCRIBERS].update_one({SUBSCRIBERS_TABLE.EMAIL: data.email}, {"$set": {SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.ACTIVE, SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
		log(LogType.SUCCESS, f"Successfully granted access for {data.days} days to user {tradingview_username} with email = {data.email}, BY_ADMIN")

	expiration = access_status["expiration"]
	expiration_timestamp = datetime.strptime(access_status["expiration"], "%Y-%m-%d %H:%M:%S.%f%z").timestamp()
	insert = {"$set": {
		SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
		SUCCESS_TABLE.EXPIRATION: expiration,
		SUCCESS_TABLE.EXPIRATION_TIMESTAMP: expiration_timestamp,
		SUCCESS_TABLE.EXPIRED: False,
		SUCCESS_TABLE.PAYMENT_TYPE: "ADMIN_RENEWED",
		SUCCESS_TABLE.SUBSCRIPTION_TYPE: "months" if data.days <= 30 else "years"
	}}
	db_instance[TABLES.SUCCESS].find_one_and_update({SUCCESS_TABLE.SUB_ID: doc[SUBSCRIBERS_TABLE.SUB_ID]}, insert)
	log(LogType.SUCCESS, f"Added data to Success table")

	#TODO Send email if necessary and email is also valid
	return {"data": f"Successfully granted access for {data.days} days to user {tradingview_username}, BY_ADMIN"}

@router.post("/revoke-access")
async def remove_access_from(data: RevokeAccess, user: User = Depends(current_active_user)) -> JSONResponse:
	"""
		data = {
			tradingview_username: str
		}
	"""
	if user is None:
		return JSONResponse({"error": "Unauthorized"}, 401)
	
	doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: data.email}, {"_id": 0})
	if doc is None:
		return JSONResponse({"error": "No Data found with given Tradingview Username"}, 401)
	tradingview_username = doc[SUBSCRIBERS_TABLE.USERNAME]
	access_status = delete_access(tradingview_username, {"pine_ids": [PUB_ID]})
	if access_status is None:
		reason = f"Issue while removing access for user = {tradingview_username} for strategy_name = {STRATEGY_NAME} check with backend. BY_ADMIN"
		failed = FAILED(doc[SUBSCRIBERS_TABLE.EMAIL],
				  doc[SUBSCRIBERS_TABLE.FULLNAME], 
				  STRATEGY_NAME, 
				  create_time=datetime.now().strftime(DT_FORMAT), 
				  reason=reason)
		db_instance[TABLES.FAILED].insert_one(failed.to_dict())
		log(LogType.ERROR, reason)

		return JSONResponse({"error": reason}, status_code=400)
	else:
		db_instance[TABLES.SUBSCRIBERS].update_one({SUBSCRIBERS_TABLE.EMAIL: data.email}, {"$set": {SUBSCRIBERS_TABLE.STATUS: SUBSCRIBER_STATUS.EXPIRED, SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
		log(LogType.SUCCESS, f"Successfully removed access for user {tradingview_username}, BY_ADMIN")

	
	insert = {"$set": {
		SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
		SUCCESS_TABLE.EXPIRED: True,
		SUCCESS_TABLE.PAYMENT_TYPE: "ADMIN_REVOKED"
	}}
	db_instance[TABLES.SUCCESS].find_one_and_update({SUCCESS_TABLE.SUB_ID: doc[SUBSCRIBERS_TABLE.SUB_ID]}, insert)
	log(LogType.SUCCESS, f"Added data to Success table")

	return {"data": f"Successfully revoked access for user {tradingview_username}, BY_ADMIN"}

@router.post("/add-user")
async def add_user(data: AddUser, user: User = Depends(current_active_user)) -> JSONResponse:
	"""
	number_of_days: int = None
    tradingview_username: str = None
    email: str = None
    fullname: str = None
	"""	
	doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: data.email})
	if doc is not None:
		log(LogType.ERROR, f"User already exists with email {data.email}, BY ADMIN")
		return JSONResponse({"error": f"User already exists with email {data.email}, BY ADMIN"}, status_code=400)

	elif not verify_user(data.tradingview_username):
		reason = f"Not a valid TradingView Username {data.tradingview_username}, BY ADMIN"
		failed = FAILED(data.email, data.fullname, STRATEGY_NAME, create_time=datetime.now().strftime(DT_FORMAT), reason=reason)
		db_instance[TABLES.FAILED].insert_one(failed.to_dict())
		log(LogType.ERROR, reason)
		return JSONResponse({"error": reason}, status_code=400)
	
	access_status = post_access(data.tradingview_username.lower(), payload={"pine_ids": [PUB_ID], "duration": f"{data.number_of_days}D"})
	if access_status is None:
		reason = f"Issue while granting access to user = {data.tradingview_username} for strategy_name = {STRATEGY_NAME}, Contact Us. BY ADMIN"
		failed = FAILED(data.email, data.fullname, STRATEGY_NAME, create_time=datetime.now().strftime(DT_FORMAT), reason=reason)
		db_instance[TABLES.FAILED].insert_one(failed.to_dict())
		log(LogType.ERROR, reason)
		return JSONResponse({"error": reason}, status_code=400)

	sub_id = str(uuid.uuid4())
	create_subscriber(db_instance, sub_id, data.email, data.fullname, data.tradingview_username)
	log(LogType.SUCCESS, f"Successfully granted access for {data.number_of_days} days to user {data.tradingview_username} with email = {data.email}, BY_ADMIN")

	expiration = access_status["expiration"]
	expiration_timestamp = datetime.strptime(access_status["expiration"], "%Y-%m-%d %H:%M:%S.%f%z").timestamp()
	insert = {
		SUCCESS_TABLE.SUB_ID: sub_id,
		SUCCESS_TABLE.CREATE_TIME: datetime.now().strftime(DT_FORMAT),
		SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
		SUCCESS_TABLE.EXPIRATION: expiration,
		SUCCESS_TABLE.EXPIRATION_TIMESTAMP: expiration_timestamp,
		SUCCESS_TABLE.EXPIRED: False,
		SUCCESS_TABLE.PAYMENT_TYPE: "NEW",
		SUCCESS_TABLE.SUBSCRIPTION_TYPE: "months" if data.number_of_days <= 30 else "years"
	}
	db_instance[TABLES.SUCCESS].insert_one(insert)
	log(LogType.SUCCESS, f"Added data to Success table, BY_ADMIN")

	#TODO Send email if necessary and email is also valid
	return JSONResponse({"data": "Success"}, status_code=200)

@router.put("/update-user")
async def update_user(data: UpdateUser, user: User = Depends(current_active_user)) -> JSONResponse:
	"""
	email: str = None

    update_fullname: Optional[str]
    update_tradingview_username: Optional[str]
	"""
	doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: data.email})
	if doc is None:
		log(LogType.ERROR, f"User doen't exist with email {data.email}, BY ADMIN")
		return JSONResponse({"error": f"User doen't exist with email {data.email}, BY ADMIN"}, status_code=400)
	
	elif len(data.update_tradingview_username) > 0 and not verify_user(data.update_tradingview_username):
		reason = f"Not a valid TradingView Username {data.update_tradingview_username}, BY ADMIN"
		failed = FAILED(data.email, doc[SUBSCRIBERS_TABLE.FULLNAME], STRATEGY_NAME, create_time=datetime.now().strftime(DT_FORMAT), reason=reason)
		db_instance[TABLES.FAILED].insert_one(failed.to_dict())
		log(LogType.ERROR, reason)
		return JSONResponse({"error": reason}, status_code=400)

	response = "UPDATED"

	if len(data.update_fullname) > 0:
		db_instance[TABLES.SUBSCRIBERS].find_one_and_update(filter={SUBSCRIBERS_TABLE.EMAIL: data.email}, 
													  update={"$set": {SUBSCRIBERS_TABLE.FULLNAME: data.update_fullname, 
													  SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
		
		db_instance[TABLES.FAILED].update_many({FAILED_TABLE.EMAIL: data.email}, 
												  {"$set": {FAILED_TABLE.SUBSCRIBER_NAME: data.update_fullname}})
		response += " FULLNAME"

	if len(data.update_tradingview_username) > 0:
		with open("credentials.json") as file:
			demo = json.load(file)
			file.close()
		DEMO_DAYS = demo["demo_days"]
		number_of_days = DEMO_DAYS
		original_tv = doc[SUBSCRIBERS_TABLE.USERNAME]
		success = db_instance[TABLES.SUCCESS].find_one({SUCCESS_TABLE.SUB_ID: doc[SUBSCRIBERS_TABLE.SUB_ID]})
		if success is not None and not success[SUCCESS_TABLE.EXPIRED]:
			log(LogType.INFO, f"Trying to remove access for original user, {original_tv} for email {data.email}. BY ADMIN")
			access_status = delete_access(original_tv, {"pine_ids": [PUB_ID]})
			if access_status is None:
				reason = f"Issue while removing access for user = {original_tv} for strategy_name = {STRATEGY_NAME} check with backend. BY_ADMIN"
				failed = FAILED(doc[SUBSCRIBERS_TABLE.EMAIL],
						doc[SUBSCRIBERS_TABLE.FULLNAME] if len(data.update_fullname) == 0 else data.update_fullname, 
						STRATEGY_NAME, 
						create_time=datetime.now().strftime(DT_FORMAT), 
						reason=reason)
				db_instance[TABLES.FAILED].insert_one(failed.to_dict())
				log(LogType.ERROR, reason)

				return JSONResponse({"error": response + " " + reason}, status_code=400)
			else:
				log(LogType.SUCCESS, f"Successfully removed access for user {original_tv}, BY_ADMIN")

			now_timestamp = datetime.now(tz=pytz.timezone("UTC")).timestamp()
			days_to_expire = success[SUCCESS_TABLE.EXPIRATION_TIMESTAMP] - now_timestamp
			number_of_days = int(days_to_expire / 86400)

		
		access_status = post_access(data.update_tradingview_username.lower(), 
							payload={"pine_ids": [PUB_ID], 
							"duration": f"{number_of_days}D"})
		if access_status is None:
			reason = f"Issue while granting access to user = {data.update_tradingview_username} for strategy_name = {STRATEGY_NAME}, Contact Us. BY ADMIN"
			failed = FAILED(data.email, data.fullname, STRATEGY_NAME, create_time=datetime.now().strftime(DT_FORMAT), reason=reason)
			db_instance[TABLES.FAILED].insert_one(failed.to_dict())
			log(LogType.ERROR, reason)
			return JSONResponse({"error": response + " " + reason}, status_code=400)
		else:
			if success is None:
				expiration_timestamp = datetime.strptime(access_status["expiration"], "%Y-%m-%d %H:%M:%S.%f%z").timestamp()
				expiration = access_status["expiration"]
				insert = {
					SUCCESS_TABLE.SUB_ID: doc[SUBSCRIBERS_TABLE.SUB_ID],
					SUCCESS_TABLE.CREATE_TIME: datetime.now().strftime(DT_FORMAT),
					SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
					SUCCESS_TABLE.EXPIRATION: expiration,
					SUCCESS_TABLE.EXPIRATION_TIMESTAMP: expiration_timestamp,
					SUCCESS_TABLE.EXPIRED: False,
					SUCCESS_TABLE.PAYMENT_TYPE: "NEW",
                	SUCCESS_TABLE.SUBSCRIPTION_TYPE: "DEMO on update"
				}
				db_instance[TABLES.SUCCESS].insert_one(insert)
			log(LogType.SUCCESS, f"Successfully granted access to new TV Username {data.update_tradingview_username} for {number_of_days} Days. BY ADMIN")
			
		

		insert = {"$set": {
			SUCCESS_TABLE.LAST_UPDATED_TIME: datetime.now().strftime(DT_FORMAT),
		}}
		db_instance[TABLES.SUCCESS].find_one_and_update({SUCCESS_TABLE.SUB_ID: doc[SUBSCRIBERS_TABLE.SUB_ID]}, insert)


		db_instance[TABLES.SUBSCRIBERS].find_one_and_update(filter={SUBSCRIBERS_TABLE.EMAIL: data.email}, 
													  update={"$set": {SUBSCRIBERS_TABLE.USERNAME: data.update_tradingview_username, 
																		SUBSCRIBERS_TABLE.LAST_UPDATED: datetime.now().strftime(DT_FORMAT)}})
		response += ", TV USERNAME"

	response +=  f" for email = {data.email}"
	return JSONResponse({"data": response}, status_code=201)

@router.delete("/delete-user")
async def delete_user(data: RemoveUser, user: User = Depends(current_active_user)) -> JSONResponse:
	"""
	email: str = None
	"""
	doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: data.email})
	if doc is None:
		log(LogType.ERROR, f"User doesn't exist with email {data.email}, BY ADMIN")
		return JSONResponse({"error": f"User doesn't exist with email {data.email}, BY ADMIN"}, status_code=400)


	# TODO: remove from subscriber, from class plus, from failed, from success, from payment
	sub_id = doc[SUBSCRIBERS_TABLE.SUB_ID]

	db_instance[TABLES.SUBSCRIBERS].delete_many({SUBSCRIBERS_TABLE.SUB_ID: sub_id})
	db_instance[TABLES.SUCCESS].delete_many({SUCCESS_TABLE.SUB_ID: sub_id})
	db_instance[TABLES.PAYMENT].delete_many({PAYMENT_TABLE.SUB_ID: sub_id})
	db_instance[TABLES.FAILED].delete_many({FAILED_TABLE.EMAIL: data.email})
	log(LogType.INFO, "Successfully removed all the entries for {data.email}, BY ADMIN")
	return JSONResponse({"data": f"Successfully removed all the entries for {data.email}, BY ADMIN"})

@router.get("/get-user-by-email")
async def get_user_by_email(email: str, User = Depends(current_active_user)) -> JSONResponse:
	
	doc = db_instance[TABLES.SUBSCRIBERS].find_one({SUBSCRIBERS_TABLE.EMAIL: email}, {"_id": 0})
	if doc is None:
		return JSONResponse({"error": "User with email doesn't exist"}, status_code=400)
	
	return doc
	...

@router.post("/set-demo-days")
async def set_demo_days(number_of_days: str, user: User = Depends(current_active_user)) -> JSONResponse:

	
	with open("credentials.json", "r") as file:
		data = json.load(file)
		file.close()

	data["demo_days"] = number_of_days
	with open("credentials.json", "w") as file:
		json.dump(data, file)
		file.close()
	
	log(LogType.SUCCESS, f"Admin set DEMO_DAYS = {number_of_days}")
	return JSONResponse({"data": f"Admin set DEMO_DAYS = {number_of_days}"})

@router.post("/set-sleep-time")
async def set_sleep_time(sleep_seconds: str, user: User = Depends(current_active_user)) -> JSONResponse:

	
	with open("credentials.json", "r") as file:
		data = json.load(file)
		file.close()

	data["sleep_time"] = sleep_seconds
	with open("credentials.json", "w") as file:
		json.dump(data, file)
		file.close()
	
	log(LogType.SUCCESS, f"Admin set SLEEP_TIME = {sleep_seconds}")
	return JSONResponse({"data": f"Admin set SLEEP_TIME = {sleep_seconds}"})