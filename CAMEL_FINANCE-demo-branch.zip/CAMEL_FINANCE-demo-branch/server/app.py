from contextlib import asynccontextmanager
from multiprocessing import Process

import fastapi_users
from .scheduler import scheduler
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI
from .routes import *
from .manager import main
from .user_manager import *
from .support.models import *
from .support.schemas import *
from beanie import init_beanie
from .support.database import db
from .support.models import models
from .support.async_payment_processor import webhook_url #ignore

main()

@asynccontextmanager
async def lifespan(app):
    print("Starting")
    await init_beanie(
		database=db,
		document_models=models,
	)
    yield  # The application is running here

    scheduler.shutdown()

app = FastAPI(lifespan=lifespan, swagger_ui_parameters={"defaultModelsExpandDepth": -1})
app.include_router(
	fastapi_users.get_auth_router(auth_backend), prefix="/auth/jwt", tags=["auth"]
)
app.include_router(
	fastapi_users.get_register_router(UserRead, UserCreate),
	prefix="/auth",
	tags=["auth"],
)
# TODO: Copy files in the module or find a better solution (fastapi_users.py, reset.py, manager.py)
app.include_router(
	fastapi_users.get_reset_password_router(),
	prefix="/auth",
	tags=["auth"],
)
app.include_router(
	fastapi_users.get_verify_router(UserRead),
	prefix="/auth",
	tags=["auth"],
)
app.include_router(
	fastapi_users.get_users_router(UserRead, UserUpdate),
	prefix="/users",
	tags=["users"],
)
app.include_router(admin_router)
app.include_router(instamojo_router)

origins = [
    "*"
]

app.add_middleware(
	CORSMiddleware,
	allow_origins=origins,
	allow_credentials=True,
	allow_methods=["*"],
	allow_headers=["*"],
)

scheduler.start()   

