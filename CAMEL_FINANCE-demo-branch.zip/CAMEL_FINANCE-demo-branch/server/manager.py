
import asyncio
import traceback
from .support.schemas import *
from pymongo import MongoClient
import json
import os
from .support.functions import log, check_if_ran_first_time
from .support.enums import LogType, CREDENTIALS_KEYS

if not os.path.exists("credentials.json"):
    log(LogType.ERROR, "No credentials.json")
    exit(0)

with open("credentials.json", "r") as file:
    credentials = json.load(file)
    file.close() 

DB_NAME = credentials[CREDENTIALS_KEYS.DATABASE]
STRATEGY_NAME = credentials[CREDENTIALS_KEYS.STRATEGY_NAME]
PUB_ID = credentials[CREDENTIALS_KEYS.STRATEGY_PUBID]
# PAYMENT_LINK = credentials[CREDENTIALS_KEYS.PAYMENT_LINK]

# EMAIL_SEND = credentials[CREDENTIALS_KEYS.SEND_EMAIL]
# EMAIL_FROM = credentials[CREDENTIALS_KEYS.SENDERS_EMAIL]

# MAIL_TOKEN = credentials[CREDENTIALS_KEYS.MAIL_TOKEN]
# CLASS_PLUS_TOKEN = credentials[CREDENTIALS_KEYS.CLASSPLUS_TOKEN]
# SUBSCRIBE_TEMPLATE = credentials[CREDENTIALS_KEYS.SUBSCRIBE_TEMPLATE]
# RENEW_TEMPLATE = credentials[CREDENTIALS_KEYS.RENEW_TEMPLATE]

JWT_SECRET_KEY = "SOMEREALLYSECRETSECRETKEY"
DT_FORMAT = "%Y-%m-%d %H:%M:%S"

url = f"mongodb://{credentials[CREDENTIALS_KEYS.DB_UNAME]}{':' if len(credentials[CREDENTIALS_KEYS.DB_UNAME]) != 0 else ''}{credentials[CREDENTIALS_KEYS.DB_PASSWORD]}{'@' if len(credentials[CREDENTIALS_KEYS.DB_UNAME]) != 0 else ''}{credentials[CREDENTIALS_KEYS.HOST]}:27017/{credentials[CREDENTIALS_KEYS.DATABASE]}"
print(url)
try:
    db_instance = MongoClient(url)[credentials[CREDENTIALS_KEYS.DATABASE]]
    log(LogType.SUCCESS, "DB Connected")
except:
    log(LogType.ERROR, "DB couldn't connect")
    log(LogType.ERROR, traceback.format_exc(limit=1))
    exit(0)

task_queue = asyncio.Queue()

def main():
    check_if_ran_first_time(db_instance, credentials[CREDENTIALS_KEYS.ADMIN_USERNAME], credentials[CREDENTIALS_KEYS.ADMIN_PASSWORD], credentials[CREDENTIALS_KEYS.ADMIN_TOKEN])

